using UnityEngine;

public class CameraFollowObject : MonoBehaviour
{
    public Transform followObject;
// Update is called once per frame
    void FixedUpdateUpdate()
    {
        Vector3 currentPosition = transform.position;
        currentPosition.x = Mathf.Lerp(currentPosition.x, followObject.position.x, .5f);
        currentPosition.z = -10;
        transform.position = currentPosition;
    }
}
