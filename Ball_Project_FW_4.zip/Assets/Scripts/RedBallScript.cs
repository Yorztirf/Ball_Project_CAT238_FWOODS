using UnityEngine;

public class RedBallScript : MonoBehaviour
{
    public float moveSpeed;
    public float jumpForce;
    public GameObject redBall;
    public Rigidbody2D my_rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()

    {// Begin Start Funtion

        jumpForce = 5;
       Debug.Log("Oh. Hello there. This is the Red Ball");
    }// End Start Funtion
        

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.D)) {
        Debug.Log("D key pressed");
        my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }
        //Note* Code below added for homework
        if (Input.GetKey(KeyCode.A)) {
        Debug.Log("A key pressed");
        my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKey(KeyCode.W) || (Input.GetKey(KeyCode.Space))) {
        Debug.Log("W key pressed");
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }
    }
    void RedBallJump()
    //Custum Funtion should always be Verbs and Capitalized
    
    {
        Debug.Log("My First Custom Function!");
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    }
}
