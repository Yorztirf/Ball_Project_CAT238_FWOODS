using UnityEngine;
using UnityEngine.SceneManagement;

public class StartOverScript : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("collision detected");
            ChangeScene();
        }
    }

    // Update is called once per frame
    void ChangeScene()
    {
       SceneManager.LoadScene(0); 
    }
}