using UnityEngine;

public class GreenBallScript : MonoBehaviour
{
    public float moveSpeed;
    public float jumpForce;
    public GameObject greenBall;
    public Rigidbody2D my_rb;
    // Note* my_rb or rb is standard for rigigd body

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {// Begin Start Funtion
        jumpForce = 5;
       Debug.Log("Oh. Hello there. This is the Green Ball");
    }// End Start Funtion

    // Note* Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow)) {
        Debug.Log("Right arrow key pressed");
        my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }
        //Note* Code below added for homework
        if (Input.GetKey(KeyCode.LeftArrow)) {
        Debug.Log("Left arrow key pressed");
        my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKey(KeyCode.UpArrow) || (Input.GetKey(KeyCode.Space))) {
        Debug.Log("Up arrow key pressed");
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }
    }
    void GreenBallJump()
    //Custum Funtion should always be Verbs and Capitalized
    {
        Debug.Log("My First Custom Function!");
        my_rb.Addforce(Vector2.up * jumpforce, ForceMode2D.Impulse);
    }
    //Note* all force is kept track of using vectors. The two numbers are represented by X and Y
    //To add a custum Vector 2 use "(,)" = (x,y) <- Important to remember that you cant multiply in Unity 2D yet. So vector2._(0,1)*jumpForce will = error
    // if computer detects input then it should find out which key is getting pressed then it should look for keycode for whatever arrow or direction.
    // || Two pipes tells the computer that this means or
}
