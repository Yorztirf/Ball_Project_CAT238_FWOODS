using UnityEngine;

public class BlueBallScript : MonoBehaviour
{
    public float moveSpeed;
    public float jumpForce;
    public GameObject blueBall;
    public Rigidbody2D my_rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()

    {// Begin Start Funtion

        jumpForce = 5;
       Debug.Log("Oh. Hello there. This is the Blue Ball");
    }// End Start Funtion
        

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow)) {
        Debug.Log("Right arrow key pressed");
        my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }
        //Note* Code below added for homework
        if (Input.GetKey(KeyCode.LeftArrow)) {
        Debug.Log("Left arrow key pressed");
        my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKey(KeyCode.UpArrow) || (Input.GetKey(KeyCode.Space))) {
        Debug.Log("Up arrow key pressed");
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }
    }
    void BlueBallJump()
    //Custum Funtion should always be Verbs and Capitalized
    {
        Debug.Log("My First Custom Function!");
        my_rb.Addforce(Vector2.up * jumpforce, ForceMode2D.Impulse);
    }
}
