using UnityEngine;

public class FirstScript : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
       Debug.Log("I am awake.");//This code will print the phrase "I am awake." to the console when the game starts.
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log("I am running.");
    }
}